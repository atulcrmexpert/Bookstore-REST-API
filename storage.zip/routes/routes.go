package routes

import (
    "net/http"
    "example.com/bookstore/handlers"
    "example.com/bookstore/storage"
)

func SetupRoutes() *http.ServeMux {
    mux := http.NewServeMux()
    store := storage.NewMemoryStore()
    h := handlers.NewBookHandler(store)

    mux.HandleFunc("/books", h.Books)
    mux.HandleFunc("/books/", h.BookByID) // handles /books/{id}

    // Simple health check
    mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
        w.WriteHeader(http.StatusOK)
        w.Write([]byte("ok"))
    })

    return mux
}
