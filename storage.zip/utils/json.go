package utils

import (
    "encoding/json"
    "net/http"
)

func WriteJSON(w http.ResponseWriter, v interface{}, status int) {
    w.Header().Set("Content-Type", "application/json; charset=utf-8")
    w.WriteHeader(status)
    enc := json.NewEncoder(w)
    enc.SetIndent("", "  ")
    _ = enc.Encode(v)
}

func JSONError(w http.ResponseWriter, status int, msg string) {
    WriteJSON(w, map[string]string{"error": msg}, status)
}
