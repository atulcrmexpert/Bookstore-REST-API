package handlers

// This file is intentionally left small — primary helpers live in utils package.
