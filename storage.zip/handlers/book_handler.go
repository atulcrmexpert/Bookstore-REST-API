package handlers

import (
    "encoding/json"
    "net/http"
    "strconv"
    "strings"

    "example.com/bookstore/models"
    "example.com/bookstore/storage"
    "example.com/bookstore/utils"
)

type BookHandler struct {
    Store *storage.MemoryStore
}

func NewBookHandler(s *storage.MemoryStore) *BookHandler {
    return &BookHandler{Store: s}
}

// List or search books: GET /books?search=term
// Create book: POST /books  (JSON body)
func (h *BookHandler) Books(w http.ResponseWriter, r *http.Request) {
    switch r.Method {
    case http.MethodGet:
        q := r.URL.Query().Get("search")
        if strings.TrimSpace(q) == "" {
            all := h.Store.GetAll()
            utils.WriteJSON(w, all, http.StatusOK)
            return
        }
        res := h.Store.Search(q)
        utils.WriteJSON(w, res, http.StatusOK)
    case http.MethodPost:
        var b models.Book
        if err := json.NewDecoder(r.Body).Decode(&b); err != nil {
            utils.JSONError(w, http.StatusBadRequest, "invalid json") 
            return
        }
        if strings.TrimSpace(b.Title) == "" || strings.TrimSpace(b.Author) == "" {
            utils.JSONError(w, http.StatusBadRequest, "title and author required")
            return
        }
        created := h.Store.Add(b)
        utils.WriteJSON(w, created, http.StatusCreated)
    default:
        utils.JSONError(w, http.StatusMethodNotAllowed, "method not allowed")
    }
}

// GET /books/{id}  DELETE /books/{id}
func (h *BookHandler) BookByID(w http.ResponseWriter, r *http.Request) {
    // path like /books/3
    parts := strings.Split(strings.Trim(r.URL.Path, "/"), "/")
    if len(parts) != 2 {
        utils.JSONError(w, http.StatusNotFound, "not found")
        return
    }
    id, err := strconv.Atoi(parts[1])
    if err != nil {
        utils.JSONError(w, http.StatusBadRequest, "invalid id")
        return
    }

    switch r.Method {
    case http.MethodGet:
        b, err := h.Store.GetByID(id)
        if err != nil {
            utils.JSONError(w, http.StatusNotFound, "book not found")
            return
        }
        utils.WriteJSON(w, b, http.StatusOK)
    case http.MethodDelete:
        if err := h.Store.Delete(id); err != nil {
            utils.JSONError(w, http.StatusNotFound, "book not found")
            return
        }
        w.WriteHeader(http.StatusNoContent)
    default:
        utils.JSONError(w, http.StatusMethodNotAllowed, "method not allowed")
    }
}
