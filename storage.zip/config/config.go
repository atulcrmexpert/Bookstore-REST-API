package config

// Simple configuration for the app.
type Config struct {
    Port int
}

func Load() *Config {
    // For simplicity, values are hard-coded.
    return &Config{Port: 8080}
}
