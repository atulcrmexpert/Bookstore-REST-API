package storage

import (
    "errors"
    "sync"
	"strings"
    "example.com/bookstore/models"
)

var ErrNotFound = errors.New("not found")

type MemoryStore struct {
    mu    sync.Mutex
    books map[int]models.Book
    next  int
}

func NewMemoryStore() *MemoryStore {
    return &MemoryStore{
        books: make(map[int]models.Book),
        next:  1,
    }
}

func (s *MemoryStore) Add(b models.Book) models.Book {
    s.mu.Lock()
    defer s.mu.Unlock()
    b.ID = s.next
    s.next++
    s.books[b.ID] = b
    return b
}

func (s *MemoryStore) GetAll() []models.Book {
    s.mu.Lock()
    defer s.mu.Unlock()
    out := make([]models.Book, 0, len(s.books))
    for _, v := range s.books {
        out = append(out, v)
    }
    return out
}

func (s *MemoryStore) GetByID(id int) (models.Book, error) {
    s.mu.Lock()
    defer s.mu.Unlock()
    b, ok := s.books[id]
    if !ok {
        return models.Book{}, ErrNotFound
    }
    return b, nil
}

func (s *MemoryStore) Delete(id int) error {
    s.mu.Lock()
    defer s.mu.Unlock()
    if _, ok := s.books[id]; !ok {
        return ErrNotFound
    }
    delete(s.books, id)
    return nil
}

func (s *MemoryStore) Search(q string) []models.Book {
    s.mu.Lock()
    defer s.mu.Unlock()
    q = strings.ToLower(q)
    out := []models.Book{}
    for _, b := range s.books {
        if strings.Contains(strings.ToLower(b.Title), q) ||
           strings.Contains(strings.ToLower(b.Author), q) ||
           strings.Contains(strings.ToLower(b.ISBN), q) {
            out = append(out, b)
        }
    }
    return out
}
